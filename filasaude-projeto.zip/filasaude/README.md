# 🏥 FilaSaúde

**Menos espera. Mais organização.**

Protótipo acadêmico desenvolvido para demonstrar uma solução tecnológica para o problema das longas filas na saúde pública.

## Funcionalidades

- Cadastro de solicitações;
- Consulta por protocolo;
- Tipos: consulta, exame e encaminhamento;
- Prioridades: baixa, normal, alta e urgente;
- Dashboard com indicadores;
- Tabela da fila com filtros;
- Tempo estimado demonstrativo;
- Interface responsiva para celular;
- Modo claro/escuro;
- Armazenamento local com `localStorage`.

## Tecnologias

HTML5 • CSS3 • JavaScript • LocalStorage • Git • GitHub • Render

## Como executar

1. Abra a pasta no VS Code.
2. Instale a extensão **Live Server**.
3. Abra `index.html` com **Open with Live Server**.

Também é possível abrir o `index.html` diretamente no navegador, porque esta versão não depende de backend.

## Estrutura

```text
filasaude/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── README.md
```

## Importante

Este projeto é um **protótipo educacional**. Não use dados reais de pacientes.

Uma versão real precisaria de backend seguro, autenticação, controle de acesso, banco de dados, criptografia, auditoria, proteção de dados e adequação à LGPD.

## Próxima evolução

Arquitetura planejada:

```text
Front-end
   ↓
API / Backend
   ↓
PostgreSQL
   ↓
Deploy
```

Possíveis endpoints futuros:

- `GET /solicitacoes`
- `POST /solicitacoes`
- `GET /solicitacoes/:id`
- `PUT /solicitacoes/:id`
- `GET /fila`
- `GET /indicadores`
